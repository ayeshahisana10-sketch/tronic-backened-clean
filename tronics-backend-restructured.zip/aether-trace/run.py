"""
Convenience entrypoint: `python run.py` starts the dev server with reload.
Equivalent to `uvicorn app.main:app --reload`.
"""
import os
import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "8000")),
        reload=True,
    )
