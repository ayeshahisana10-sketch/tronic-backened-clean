"""
Tracing tests. All external calls (TronGrid, TRONSCAN) are mocked so these
run offline and deterministically -- no live network access required.
"""
from unittest.mock import patch

from fastapi.testclient import TestClient

from app.main import app
from app.services import tracing_service

client = TestClient(app)

SUSPECT = "TWPma8xH48AEN93x2krdukV9e1j6sPsBeS"
HOP1 = "TVLdV1SzHwoWSywjMPZ3nWm81jZUqVJcAB"
EXCHANGE = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6a"


def _raw_transfer(from_addr, to_addr, amount_usdt, decimals=6, tx="0xabc", ts=1000):
    return {
        "transaction_id": tx,
        "from": from_addr,
        "to": to_addr,
        "value": str(int(amount_usdt * (10 ** decimals))),
        "block_timestamp": ts,
        "token_info": {"address": "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t", "decimals": decimals},
    }


def test_invalid_address_rejected():
    resp = client.post("/trace", json={"suspect_address": "not-a-real-address"})
    assert resp.status_code == 400


def test_no_outbound_transfers_is_unattributed():
    with patch("app.services.tracing_service.get_usdt_transfers", return_value=[]):
        report = tracing_service.trace_wallet(SUSPECT)
    assert report.confidence_tier == "UNATTRIBUTED"
    assert report.hops == []


def test_confirmed_when_hop1_has_label():
    def fake_transfers(address, only_from=True):
        if address == SUSPECT:
            return [_raw_transfer(SUSPECT, HOP1, 500)]
        return []

    with patch("app.services.tracing_service.get_usdt_transfers", side_effect=fake_transfers), \
         patch("app.services.tracing_service.get_tronscan_label", return_value="Binance Hot Wallet"):
        report = tracing_service.trace_wallet(SUSPECT)

    assert report.confidence_tier == "CONFIRMED"
    assert report.final_destination == HOP1
    assert report.final_destination_label == "Binance Hot Wallet"


def test_probable_when_hop1_sweeps_to_labeled_hop2():
    def fake_transfers(address, only_from=True):
        if address == SUSPECT:
            return [_raw_transfer(SUSPECT, HOP1, 500)]
        if address == HOP1:
            return [_raw_transfer(HOP1, EXCHANGE, 495)]
        return []

    def fake_label(address):
        return "Binance Hot Wallet" if address == EXCHANGE else None

    with patch("app.services.tracing_service.get_usdt_transfers", side_effect=fake_transfers), \
         patch("app.services.tracing_service.get_tronscan_label", side_effect=fake_label):
        report = tracing_service.trace_wallet(SUSPECT)

    assert report.confidence_tier == "PROBABLE"
    assert report.final_destination == EXCHANGE
    assert report.final_destination_label == "Binance Hot Wallet"
    assert len(report.hops) == 2
