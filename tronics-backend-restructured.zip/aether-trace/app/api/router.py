from fastapi import APIRouter

from .routes import health, trace

api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(trace.router, tags=["trace"])
