"""
CORS / security wiring for the TRONICS API.

Kept separate from main.py so the allowed-origins policy is a single,
obvious place to tighten before any real deployment.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# TODO: tighten before any real deployment -- "*" is fine for an MVP demo only.
ALLOWED_ORIGINS = ["*"]
ALLOWED_METHODS = ["*"]
ALLOWED_HEADERS = ["*"]


def configure_cors(app: FastAPI) -> None:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=ALLOWED_ORIGINS,
        allow_methods=ALLOWED_METHODS,
        allow_headers=ALLOWED_HEADERS,
    )
