"""
Thin wrapper around TRONSCAN (address labels).
"""
from typing import Optional
import httpx

from ..core import config


def get_tronscan_label(address: str) -> Optional[str]:
    """
    Look up a public TRONSCAN label for an address (e.g. exchange hot wallet
    tags). Returns None if no label is found or the lookup fails -- a failed
    lookup must never be treated as "confirmed no label", it should fall
    through to behavioral analysis.
    """
    url = f"{config.TRONSCAN_BASE_URL}/accountv2"
    params = {"address": address}
    headers = {"accept": "application/json"}
    if config.TRONSCAN_API_KEY:
        headers["TRON-PRO-API-KEY"] = config.TRONSCAN_API_KEY

    try:
        resp = httpx.get(url, headers=headers, params=params,
                          timeout=config.REQUEST_TIMEOUT_SECONDS)
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPError:
        return None  # do not fail the whole trace over a label lookup

    name = data.get("name") or ""
    tag = data.get("addressTag", {}) or {}
    tag_name = tag.get("name") if isinstance(tag, dict) else None

    label = name or tag_name
    return label if label else None
