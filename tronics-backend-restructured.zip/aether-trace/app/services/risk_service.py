"""
TRONICS risk heuristics.

  - Bridge contracts are flagged, never traced further (detection only)
  - Sweep detection: a hop wallet that forwards >= SWEEP_RATIO_THRESHOLD of
    what it received, quickly, is treated as an intermediary/deposit wallet
"""
from typing import Dict, List, Optional, Tuple

from ..core import config


def check_bridge(address: str) -> Tuple[bool, Optional[str]]:
    """Return (is_bridge, bridge_name) for a known TRON bridge contract."""
    name = config.KNOWN_BRIDGE_ADDRESSES.get(address)
    return (True, name) if name else (False, None)


def detect_sweep(outbound: List[Dict]) -> Tuple[bool, float, Optional[Dict]]:
    """
    Given a list of normalized outbound transfers for an address, decide
    whether the address swept most of its volume out in one transfer.

    Returns (swept, total_out_usdt, sweep_transfer_or_none).
    """
    if not outbound:
        return False, 0.0, None

    total_out = sum(t["amount_usdt"] for t in outbound)
    largest = max(outbound, key=lambda t: t["amount_usdt"])

    if total_out > 0 and (largest["amount_usdt"] / total_out) >= config.SWEEP_RATIO_THRESHOLD:
        return True, total_out, largest

    return False, total_out, None
