"""
TRONICS backend.

Endpoints:
  POST /trace              -> run a 1-2 hop USDT-TRC20 trace on a suspect address
  POST /complaint-intake   -> MOCK NCRP/SAHYOG-style intake (clearly labeled, not
                              a real government integration -- none exists publicly)
  GET  /health             -> basic liveness check

Run locally:
  pip install -r requirements.txt
  export TRONGRID_API_KEY=your_key
  uvicorn app.main:app --reload
"""
from fastapi import FastAPI

from .core.security import configure_cors
from .api.router import api_router

app = FastAPI(
    title="TRONICS",
    description=(
        "SIH26183 prototype: 1-2 hop USDT-TRC20 fund tracing from "
        "victim-reported TRON addresses toward possible exchange deposit points. "
        "All attributions are probabilistic; see disclaimer in every report."
    ),
    version="0.1.0-mvp",
)

configure_cors(app)
app.include_router(api_router)
